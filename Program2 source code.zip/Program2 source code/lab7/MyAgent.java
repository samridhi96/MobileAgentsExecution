import java.io.*;
import Mobile.*;

public class MyAgent extends Agent implements Serializable {
    private String destination = null;
    public MyAgent( ) { 
	System.out.println( "Injected" );
    }

    public void init( ) {
	hop( "cssmpi2h", "hop" );
    }

    public void hop( ) {
	System.out.println( "hop" );
	hop( "cssmpi3h", "step" );
    }

    public void step( ) {
        System.out.println( "step" );
        hop( "cssmpi4h", "jump" );
    }

    public void jump( ) {
        System.out.println( "jump" );
    }

}
