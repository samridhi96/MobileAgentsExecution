#!/bin/sh

# $1: IP address to inject a given agent
# $2: Your IP port  
# $3: The agent class to inject
# $4 ~ $5: argumenets passed to the agent
 
java -cp Mobile.jar:. Mobile.Inject $1 $2 $3 $4 $5
