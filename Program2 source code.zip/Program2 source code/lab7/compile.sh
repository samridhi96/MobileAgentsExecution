#!/bin/sh

javac -cp Mobile.jar:. *.java