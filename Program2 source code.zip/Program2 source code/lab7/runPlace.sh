#!/bin/sh

# $1: Your IP port

java -cp Mobile.jar Mobile.Place $1
