#!/bin/sh
# $1 = ip1 $2 = ip2

java -cp Mobile.jar Mobile.Inject localhost 28029 MyAgent $1 $2 $3
