#!/bin/sh

java -cp Mobile.jar Mobile.Place $1
